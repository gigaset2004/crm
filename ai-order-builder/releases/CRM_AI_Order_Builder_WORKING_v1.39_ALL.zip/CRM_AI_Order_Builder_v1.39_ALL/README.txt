CRM AI Order Builder - working installation

Widget version: v1.39 (auto reload after Save SO Products)
Client Scripts: v1.33 (working with widget v1.39)

Install:
1) Zoho CRM Developer Hub > Widgets > AI Order Builder: upload the ZIP AI_Order_Builder_v1.39_CLEAN_AUTO_REFRESH.zip (included separately in the top-level archive).
2) Existing Client Script 'Fill with AI in Record' <- client-scripts/Fill_with_AI_BUTTON_v1.33.js
3) Existing Client Script 'AI Order Fill Products' <- client-scripts/Sales_Orders_CREATE_onLoad_v1.33.js
4) Existing custom button 'Fill with AI' for saved Requested SO should remain in CRM.

No changes to Sales Order Subject Client Script.
